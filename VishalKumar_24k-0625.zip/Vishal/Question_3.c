#include<stdio.h>


// Question#3


int main()

{
	
	
	float taxrate,salary,tax;
	
	
    printf("Enter tax rate");
    
    scanf("%f",&taxrate);
    
    printf("Enter salary");
    
    scanf("%f",&salary);
    
    tax = (taxrate/100)*salary;
    
    printf("The tax for this user is=%f",tax);
    
    
    return 0;
    
}
	
	
	
	
	

