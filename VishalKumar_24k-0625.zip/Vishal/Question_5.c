#include<stdio.h>

int main() {
    
    float principal;
    float rate;
    float time;
    float I;
    
    
    printf("Enter principle amount between Rs.100 to Rs.1000000:");
    
    scanf("%f",principle);  
    
    
    printf("Enter interest rate between 5 percent to 10 percent:");
    
    scanf("%f",rate);
    
    
    printf("Enter time period  :");
    
    scanf("%f",time); 
    
    
    I = (principle * rate * time) / 100;
    
    printf("The total interest is= %f",I);
    

    return 0;
}
