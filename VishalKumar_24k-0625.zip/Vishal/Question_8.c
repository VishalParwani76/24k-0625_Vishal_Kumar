#include<stdio.h>

int main()
{
	
    float dist,distmiles;
	
	printf("Enter the valuse of distance in KMs \n");
	
	scanf("%f",&dist);
	
	distmiles=dist/1.609;
	
	printf("The distance in miles =%f",distmiles);
	
	return 0;
	

	
}