#include<stdio.h>

int main()

{    
    /* int can hold values from -2,147,483,648 to 2,147,483,647 but
    3000000000 exceeds this range, so it can�t be stored in an int variable.
    On the other hand, double having 64=bit size, can store this value easily.*/
    
    
    double testinteger = 3000000000;
    
    
    printf("Number is %lf",testinteger);
    

}
