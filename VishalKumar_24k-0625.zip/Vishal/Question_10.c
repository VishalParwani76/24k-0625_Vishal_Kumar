#include<stdio.h>

int main()

{
    float BDI;
    float KG = 54;
    float meters = 1.68;
    
    scanf("%f%f",KG,meters);
    
    
    BDI =(KG)/(meters * meters);
    
    printf("The body mass index is=%f",BDI);
    
    return 0;
    
}
    
    
