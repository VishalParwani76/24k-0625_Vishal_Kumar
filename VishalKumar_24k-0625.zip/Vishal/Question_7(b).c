#include<stdio.h>

int main()
{
		
	float F,C;
	
	printf("Enter value of Fahrenhiet");
	
	scanf("%f",&F);
	
    C=(F-32) * 5/9 ;
	
	printf("The temperature in Celcius=%f",C);
	
	
	return 0;	
	
}