#include<stdio.h>

int main(){
	
	
	float F,C;
	
	printf("Enter value of C\n");
	
	scanf("%f",&C);
	
	F=((9/5)*C)+32;
	
	printf("The temperature in Fahrenheit=%f",F);
	
	
	return 0;	
	
	
}