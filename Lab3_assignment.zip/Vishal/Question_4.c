#include<stdio.h>

int main()
{
    float fuelaverage;
    float totaldistance = 1207 * 2;
    float forwardprice = 118;
    float returnprice = 123;
    float totalfuelconsumed;
    float totalfuelcost;
    {
     printf("Enter the car's fuel average: ");
    
     scanf("%f",&fuelaverage);
    
     if (fuelaverage < 0)
        printf("Fuel must be a positive number.Please try again.");
        }
        
    while (fuelaverage < 0);
    
    totalfuelconsumed = totaldistance / fuelaverage;
    
    totalfuelcost = (1207 / fuelaverage) * forwardprice + (1207 / fuelaverage) * returnprice;
   
    printf("Total fuel consumed for the trip: %f, totalfuelconsumed);
    
    printf("Total fuel cost for the trip: %f, toalfuelcost);
    
      return 0;
      
}
