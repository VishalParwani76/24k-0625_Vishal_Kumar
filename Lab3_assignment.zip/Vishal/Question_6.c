#include<stdio.h>

//Question 06  

int main()
{
    float m;
    float x1 = 5;
    float x2 = 3;
    float y1 = 4;
    float y2 = 2;
    
    
    scanf('%f%f%f%f',&x1,&x2,&y1,&y2);
    
    
    m = (y2-y1)/(x2-x1);
    
    printf('The slope of two points is=%f',m);
    
    return 0;
    
}
    
    
    
