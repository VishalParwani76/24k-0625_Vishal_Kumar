#include<stdio.h>

int main()

{

 float length = 18;
 float width = 12;
 float perimeter;
 
 
 scanf("%f%f",length,width);
 
 perimeter = (2*length) + (2*width);
 
 printf("The perimeter of rectangle is=%f",perimeter);
 
 return 0;
 
}
